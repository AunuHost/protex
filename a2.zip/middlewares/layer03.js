
module.exports = (req, res, next) => {
  // Lapisan proteksi 03
  next();
};
