
module.exports = (req, res, next) => {
  // Lapisan proteksi 45
  next();
};
