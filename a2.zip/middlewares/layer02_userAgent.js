
module.exports = (req, res, next) => {
  const ua = req.headers['user-agent'] || '';
  if (/curl|wget|bot|scan|nmap/i.test(ua)) {
    return res.status(403).send('🛡️ Akses ditolak. User-Agent mencurigakan.');
  }
  next();
};
