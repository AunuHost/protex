
const geoip = require('geoip-lite');
const blockedCountries = ['RU', 'CN', 'KP'];

module.exports = (req, res, next) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const geo = geoip.lookup(ip);
  if (geo && blockedCountries.includes(geo.country)) {
    return res.status(403).send('🌍 Akses dari wilayah Anda diblokir.');
  }
  next();
};
