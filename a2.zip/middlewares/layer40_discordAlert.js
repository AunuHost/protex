const axios = require('axios');
require('dotenv').config();

module.exports = async (req, res, next) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const ua = req.headers['user-agent'] || 'unknown';
  const log = `🚨 **Serangan Terdeteksi**
IP: \`${ip}\`
User-Agent: \`${ua}\`
Waktu: <t:${Math.floor(Date.now() / 1000)}:F>`;

  try {
    await axios.post(process.env.DISCORD_WEBHOOK_URL, {
      content: log
    });
  } catch (err) {
    console.error('[Discord Alert] Gagal mengirim notifikasi:', err.response?.data || err.message);
  }

  next();
};
