
module.exports = (req, res, next) => {
  // Lapisan proteksi 44
  next();
};
