
module.exports = (req, res, next) => {
  // Lapisan proteksi 32
  next();
};
