
module.exports = (req, res, next) => {
  // Lapisan proteksi 23
  next();
};
