
module.exports = (req, res, next) => {
  // Lapisan proteksi 38
  next();
};
