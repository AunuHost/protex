
module.exports = (req, res, next) => {
  if (req.headers['cf-connecting-ip']) {
    return res.status(403).send('🔒 Akses dari source dengan Cloudflare deteksi diblokir.');
  }
  next();
};
