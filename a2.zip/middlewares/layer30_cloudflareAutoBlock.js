
const axios = require('axios');
require('dotenv').config();

module.exports = async (req, res, next) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  if (!ip || ip.includes('127.0.0.1')) return next();

  try {
    await axios.post(`https://api.cloudflare.com/client/v4/zones/${process.env.CF_ZONE_ID}/firewall/access_rules/rules`, {
      mode: 'block',
      configuration: {
        target: 'ip',
        value: ip
      },
      notes: 'Auto-blocked by AunuHost AntiDDoS'
    }, {
      headers: {
        'X-Auth-Email': process.env.CF_EMAIL,
        'X-Auth-Key': process.env.CF_API_KEY,
        'Content-Type': 'application/json'
      }
    });
    console.log(`[Cloudflare] IP ${ip} diblokir.`);
  } catch (err) {
    console.error('[Cloudflare] Gagal blokir IP:', err.response?.data || err.message);
  }

  res.status(403).send('🚫 Akses Anda telah diblokir otomatis oleh firewall.');
};
