
module.exports = (req, res, next) => {
  // Lapisan proteksi 07
  next();
};
