
module.exports = (req, res, next) => {
  // Lapisan proteksi 36
  next();
};
