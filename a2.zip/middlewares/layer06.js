
module.exports = (req, res, next) => {
  // Lapisan proteksi 06
  next();
};
