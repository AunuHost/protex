
module.exports = (req, res, next) => {
  // Lapisan proteksi 48
  next();
};
