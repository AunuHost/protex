
module.exports = (req, res, next) => {
  // Lapisan proteksi 10
  next();
};
