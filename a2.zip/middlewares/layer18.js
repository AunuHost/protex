
module.exports = (req, res, next) => {
  // Lapisan proteksi 18
  next();
};
