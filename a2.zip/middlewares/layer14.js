
module.exports = (req, res, next) => {
  // Lapisan proteksi 14
  next();
};
