
module.exports = (req, res, next) => {
  // Lapisan proteksi 26
  next();
};
