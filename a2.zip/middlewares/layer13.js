
module.exports = (req, res, next) => {
  // Lapisan proteksi 13
  next();
};
