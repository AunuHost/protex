const fs = require('fs');
const path = require('path');

module.exports = (req, res, next) => {
  const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const log = `[${new Date().toISOString()}] Serangan dari IP: ${ip}, UA: ${req.headers['user-agent'] || 'unknown'}\\n`;
  fs.appendFile(path.join(__dirname, '../attacks.log'), log, (err) => {
    if (err) console.error('Gagal menyimpan log serangan:', err);
  });
  next();
};
