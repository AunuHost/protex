
module.exports = (req, res, next) => {
  const accept = req.headers['accept'] || '';
  const lang = req.headers['accept-language'] || '';
  const enc = req.headers['accept-encoding'] || '';
  if (!accept.includes('text/html') || !lang || !enc) {
    return res.status(403).send('🕵️ Terindikasi bot/fingerprint tidak valid');
  }
  next();
};
