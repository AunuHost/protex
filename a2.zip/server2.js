
require('dotenv').config();
const express = require('express');
const app = express();
const helmet = require('helmet');
const axios = require('axios');

app.use(helmet());
app.use(express.json());

app.use((req, res, next) => {
  setTimeout(() => next(), Math.floor(Math.random() * 200) + 50);
});

app.use((req, res, next) => {
  if (req.headers['user-agent']?.includes('bot')) return res.status(403).send('Forbidden');
  next();
});

app.use('/', async (req, res) => {
  try {
    const response = await axios({
      method: req.method,
      url: 'http://localhost:8443' + req.originalUrl,
      headers: req.headers,
      data: req.body,
    });
    res.status(response.status).send(response.data);
  } catch (err) {
    res.status(502).send('Server utama tidak merespon.');
  }
});

app.listen(process.env.PORT_SERVER2, () => {
  console.log(`🛡️ Server 2 (Proteksi) running on port ${process.env.PORT_SERVER2}`);
});
