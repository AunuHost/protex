
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const app = express();
const axios = require('axios');

for (let i = 1; i <= 50; i++) {
  app.use(require(`./middlewares/layer${i.toString().padStart(2, '0')}.js`));
}

app.use('/', async (req, res) => {
  try {
    const response = await axios({
      method: req.method,
      url: 'http://localhost:8443' + req.originalUrl,
      headers: req.headers,
      data: req.body,
    });
    res.status(response.status).send(response.data);
  } catch (err) {
    try {
      const response = await axios({
        method: req.method,
        url: process.env.FORWARD_URL + req.originalUrl,
        headers: req.headers,
        data: req.body,
      });
      res.status(response.status).send(response.data);
    } catch (e) {
      res.status(502).send('Gateway Error');
    }
  }
});

app.listen(process.env.PORT_SERVER1, () => {
  console.log(`🛡️ Server 1 running on port ${process.env.PORT_SERVER1}`);
});
