import functools

class _PY:
    def __init__(self):
        self._registry = []

    def _make_decorator(self, kind, *dargs):
        def decorator(arg=None, **kwargs):
            def _wrap(func):
                meta = getattr(func, '_py_meta', {})
                meta.update({'kind': kind, 'dargs': dargs, 'kwargs': kwargs})
                setattr(func, '_py_meta', meta)
                return func
            if callable(arg):
                return _wrap(arg)
            return _wrap
        return decorator

    def __getattr__(self, name):
        return self._make_decorator(name.lower())

PY = _PY()

class _EMO:
    async def BERHASIL(self, client=None): return "✅"
    async def GAGAL(self, client=None): return "❌"
    async def PROSES(self, client=None): return "⏳"
    async def PING(self, client=None): return "🏓"
    async def MENTION(self, client=None): return "📣"
    async def UBOT(self, client=None): return "🤖"
    async def BROADCAST(self, client=None): return "📣"
    async def BL_GROUP(self, client=None): return "🔒"
    async def BL_KETERANGAN(self, client=None): return "📝"
    async def MENUNGGU(self, client=None): return "⏱"

EMO = _EMO()
