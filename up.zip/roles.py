ROLES = ['trial','permanent','reseller','admin','owner']

def can_add_trial(role): return role in ['reseller','admin','owner']
def can_add_otp(role): return role in ['reseller','admin','owner']
def can_add_reseller(role): return role in ['admin','owner']
def can_add_admin(role): return role == 'owner'
