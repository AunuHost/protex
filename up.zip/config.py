import os
from dotenv import load_dotenv
load_dotenv()

# BOT utama
BOT_TOKEN = os.getenv("BOT_TOKEN", "8279035116:AAEJ2eJvQkrvstQes0RPLsNqaFCzXEAUVaM")

# API default untuk semua userbot
API_ID = int(os.getenv("API_ID", "29289753"))
API_HASH = os.getenv("API_HASH", "3f209b867db1920f5246bf523246fd74")

# Owner bot utama
OWNER_ID = int(os.getenv("OWNER_ID", "8359234400")) or None

# Path database JSON
DB_FILE = os.getenv("DB_FILE", "database.json")
