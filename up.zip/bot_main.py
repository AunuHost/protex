import os, importlib, asyncio, inspect, datetime
from pyrogram import Client, filters
from pyrogram.types import Message
from config import BOT_TOKEN, OWNER_ID
from database import set_role, get_role, add_ubot, list_ubots
from roles import *
from services.ubot_manager import create_trial_ubot, create_permanent_ubot, expire_check_loop

import pyroshim

if not BOT_TOKEN:
    raise SystemExit('Set BOT_TOKEN in .env before running.')

bot = Client('ubot_manager_bot', bot_token=BOT_TOKEN)
PENDING = {}  # user_id -> pending info

def load_modules_and_register():
    mod_dir = os.path.join(os.path.dirname(__file__), 'modules')
    for root, dirs, files in __import__('os').walk(mod_dir):
        for f in files:
            if f.endswith('.py') and not f.startswith('__'):
                rel = os.path.relpath(os.path.join(root,f), os.path.dirname(__file__))
                modname = rel.replace(os.sep, '.')[:-3]
                try:
                    m = importlib.import_module(modname)
                    for name, obj in inspect.getmembers(m, inspect.iscoroutinefunction):
                        meta = getattr(obj, '_py_meta', None)
                        if meta and meta.get('kind') == 'bot':
                            cmds = meta.get('dargs') or ()
                            for cmd in cmds:
                                @bot.on_message(filters.command(cmd) & filters.private)
                                async def wrapper(c, message, _obj=obj):
                                    return await _obj(c, message)
                            print('Registered bot cmd', cmd, 'from', modname)
                except Exception as e:
                    print('Failed to import', modname, e)

@bot.on_message(filters.command('start') & filters.private)
async def start_cmd(c: Client, m: Message):
    role = get_role(m.from_user.id) or 'trial'
    await m.reply_text(f'Welcome. Your role: {role}')

@bot.on_message(filters.command('trial') & filters.private)
async def trial_cmd(c, m: Message):
    role = get_role(m.from_user.id) or 'trial'
    if role != 'trial' and role not in ['reseller','admin','owner']:
        return await m.reply_text('You are not allowed to use /trial')
    args = m.text.split(maxsplit=1)
    if len(args) > 1:
        phone = args[1].strip()
        session = f"ubot_{m.from_user.id}_{int(datetime.datetime.datetime.utcnow().timestamp())}"
        PENDING[m.from_user.id] = {'type':'trial','phone':phone,'session':session, 'api_id':None, 'api_hash':None}
        await m.reply_text('Phone received. Please reply with /code <OTP> when you get the code.')
    else:
        await m.reply_text('Send phone number: /trial +62...')

@bot.on_message(filters.command('otp') & filters.private)
async def otp_cmd(c, m: Message):
    role = get_role(m.from_user.id)
    if role != 'permanent' and role not in ['reseller','admin','owner']:
        return await m.reply_text('You are not allowed to use /otp')
    args = m.text.split(maxsplit=1)
    if len(args) > 1:
        phone = args[1].strip()
        session = f"ubot_{m.from_user.id}_{int(datetime.datetime.datetime.utcnow().timestamp())}"
        PENDING[m.from_user.id] = {'type':'otp','phone':phone,'session':session, 'api_id':None, 'api_hash':None}
        await m.reply_text('Phone received. Please reply with /code <OTP> when you get the code.')
    else:
        await m.reply_text('Send phone number: /otp +62...')

@bot.on_message(filters.command('code') & filters.private)
async def code_cmd(c, m: Message):
    user = m.from_user.id
    if user not in PENDING:
        return await m.reply_text('No pending login. Start with /trial or /otp <phone>')
    args = m.text.split(maxsplit=1)
    if len(args) < 2:
        return await m.reply_text('Usage: /code <OTP>')
    code = args[1].strip()
    pend = PENDING.pop(user)
    if pend['type'] == 'trial':
        await create_trial_ubot(pend['phone'], user, pend['session'], api_id=0, api_hash='')
        await m.reply_text(f'Trial ubot registered (session: {pend['session']!r}).')
    else:
        await create_permanent_ubot(pend['phone'], user, pend['session'], api_id=0, api_hash='')
        await m.reply_text(f'Permanent ubot registered (session: {pend['session']!r}).')

@bot.on_message(filters.command('addtrial') & filters.user(OWNER_ID))
async def addtrial_owner(c,m):
    try:
        user = int(m.text.split()[1])
    except:
        return await m.reply_text('Usage: /addtrial <user_id>')
    set_role(user, 'trial')
    await m.reply_text(f'Added trial for {user}')

@bot.on_message(filters.command('addotp') & filters.user(OWNER_ID))
async def addotp_owner(c,m):
    try:
        user = int(m.text.split()[1])
    except:
        return await m.reply_text('Usage: /addotp <user_id>')
    set_role(user, 'permanent')
    await m.reply_text(f'Added permanent for {user}')

@bot.on_message(filters.command('addreseller') & filters.user(OWNER_ID))
async def addreseller_owner(c,m):
    try:
        user = int(m.text.split()[1])
    except:
        return await m.reply_text('Usage: /addreseller <user_id>')
    set_role(user, 'reseller')
    await m.reply_text(f'Added reseller {user}')

@bot.on_message(filters.command('addadmin') & filters.user(OWNER_ID))
async def addadmin_owner(c,m):
    try:
        user = int(m.text.split()[1])
    except:
        return await m.reply_text('Usage: /addadmin <user_id>')
    set_role(user, 'admin')
    await m.reply_text(f'Added admin {user}')

async def start_background_tasks():
    asyncio.create_task(expire_check_loop(60*30))

if __name__ == '__main__':
    load_modules_and_register()
    bot.start()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(start_background_tasks())
    bot.idle()
