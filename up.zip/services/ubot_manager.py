import asyncio, datetime
from database import add_ubot, list_ubots, db
running_ubots = {}

async def start_userbot(session_name, api_id, api_hash):
    # start Pyrogram client for an existing session (actual sign-in must be done separately)
    from pyrogram import Client
    if session_name in running_ubots:
        return running_ubots[session_name]
    c = Client(session_name, api_id=api_id, api_hash=api_hash)
    await c.start()
    running_ubots[session_name] = c
    return c

async def stop_userbot(session_name):
    c = running_ubots.pop(session_name, None)
    if c:
        try:
            await c.stop()
        except Exception:
            pass

async def create_trial_ubot(phone, owner_id, session_name, api_id, api_hash):
    expires = datetime.datetime.datetime.utcnow() + datetime.timedelta(days=30)
    add_ubot(owner_id, phone, session_name, permanent=False, expires_at=expires)
    return {'ok': True, 'session': session_name, 'expires_at': expires.isoformat(), 'pending': True}

async def create_permanent_ubot(phone, owner_id, session_name, api_id, api_hash):
    add_ubot(owner_id, phone, session_name, permanent=True, expires_at=None)
    return {'ok': True, 'session': session_name, 'pending': True}

async def expire_check_loop(interval_seconds=3600):
    while True:
        now = datetime.datetime.datetime.utcnow()
        if db:
            for ub in list_ubots(None):
                if ub.get('expires_at'):
                    try:
                        exp = ub['expires_at']
                        if isinstance(exp, str):
                            exp = datetime.datetime.datetime.fromisoformat(exp)
                        if exp < now:
                            sess = ub.get('session')
                            await stop_userbot(sess)
                            db.ubots.delete_one({'_id': ub['_id']})
                    except Exception:
                        pass
        await asyncio.sleep(interval_seconds)
