__MODULE__ = "ʟᴇᴀᴠᴇ ɢʟɪᴍɪᴛ"
__HELP__ = """
<b>⦪ ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ʟᴇᴀᴠᴇ ɢʟɪᴍɪᴛ ⦫</b>

<blockquote><b>⎆ perintah : 
ᚗ <code>{0}leaveallmute</code>
ᚗ Untuk keluar dari grub yang membatasi anda</b></blockquote>
"""
