import json
import os
from datetime import datetime

DB_FILE = "database.json"

# Load database from file
def load_db():
    if not os.path.exists(DB_FILE):
        return {"users": {}}
    with open(DB_FILE, "r") as f:
        return json.load(f)

# Save database to file
def save_db(db):
    with open(DB_FILE, "w") as f:
        json.dump(db, f, indent=4)

# Set user role
def set_role(user_id: int, role: str, expires_at: str = None):
    db = load_db()
    user_id = str(user_id)
    if user_id not in db["users"]:
        db["users"][user_id] = {"ubots": []}
    db["users"][user_id]["role"] = role
    if expires_at:
        db["users"][user_id]["expires_at"] = expires_at
    save_db(db)

# Get user role
def get_role(user_id: int):
    db = load_db()
    return db["users"].get(str(user_id), {}).get("role")

# Add ubot to user
def add_ubot(user_id: int, session_name: str):
    db = load_db()
    user_id = str(user_id)
    if user_id not in db["users"]:
        db["users"][user_id] = {"ubots": []}
    db["users"][user_id]["ubots"].append(session_name)
    save_db(db)

# Get all ubots of a user
def get_ubots(user_id: int):
    db = load_db()
    return db["users"].get(str(user_id), {}).get("ubots", [])

# Remove ubot
def remove_ubot(user_id: int, session_name: str):
    db = load_db()
    user_id = str(user_id)
    if user_id in db["users"]:
        if session_name in db["users"][user_id]["ubots"]:
            db["users"][user_id]["ubots"].remove(session_name)
    save_db(db)