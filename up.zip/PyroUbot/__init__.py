# lightweight compatibility package for modules expecting PyroUbot package
from pyroshim import PY, EMO
__all__ = ['PY','EMO']
